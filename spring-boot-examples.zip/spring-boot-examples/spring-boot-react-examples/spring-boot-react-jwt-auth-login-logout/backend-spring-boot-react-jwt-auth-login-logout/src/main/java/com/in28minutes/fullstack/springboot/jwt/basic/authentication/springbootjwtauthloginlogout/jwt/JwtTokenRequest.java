package com.in28minutes.fullstack.springboot.jwt.basic.authentication.springbootjwtauthloginlogout.jwt;

public record JwtTokenRequest(String username, String password) {}

