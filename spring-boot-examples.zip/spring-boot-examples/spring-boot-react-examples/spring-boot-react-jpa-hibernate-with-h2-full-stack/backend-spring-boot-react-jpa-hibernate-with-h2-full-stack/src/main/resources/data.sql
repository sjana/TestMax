insert into course(id, username,description)
values(10001, 'in28minutes', 'Learn JPA');

insert into course(id, username,description)
values(10002, 'in28minutes', 'Learn Data JPA');

insert into course(id, username,description)
values(10003, 'in28minutes', 'Learn Microservices');