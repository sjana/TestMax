package com.in28minutes.springboot.rest.example.versioning;

public record Name(String firstName,
                   String lastName) {

}