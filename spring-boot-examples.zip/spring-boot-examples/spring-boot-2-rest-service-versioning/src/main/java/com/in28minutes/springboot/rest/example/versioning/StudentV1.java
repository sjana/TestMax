package com.in28minutes.springboot.rest.example.versioning;

public record StudentV1(String name) {

}