
READ ME

How to create database for demo?

1) Create demo db instance using Cassandra, mysql or oracle. Your database instance name can be anything
2) Create 2 tables which is available in TestMaxProject/data/config/create_database.sql
3) Create table using this script
4) Make changes in db_demo.xml with you db info
5) You can create multiple tags for different database connections and use these tag as dbname in your test configuration
<sql name="q1" dbname="demodb" >
 Look at SQLTemplate.xml file located under TestMaxProject\data\module\Template path
6) Use these below attribute for oracle if you only returning dbms_output as csv (xls with column name and data row) file format 
dbmsoutput="yes" dbmstable="yes" dbmsoutputkey="Assert"

How to setup TestMax Env?

1) Download the TestMaxProject.zip
2) Unzip the project
3) In Eclipse create a new Java project pointing to the path you unzipped
4) Select the project and go to the project properties in Eclipse TestMaxProject-->Properties-->Java Build Path and make sure there all jars are added from the lib directories. If you are using Cassandra database add all jars from \lib\jdbc
5) Select TestMaxProject -->Run-->Run Configurator-->Java Application -->Click New --> Select Main Class Name=scm.wm.runner.TestRunner. Give Configuration Name=TestMax which will appear with this name under Java Application in the Run Configurator
6) Open Folder TestSuite\SampleTest.xml. Uncomment the test suite you want to run 
7) Select TestMax dropdown menu under the Eclipse Run Green traingular button.

How to run your TestSuite?

1) Go to \data\TestSuite folder
2) Add your Test Suite under uncommented portion in the XML file
3) For Non browser Test like Database, JUNIT or TestNg test cases remove  browsers, baseurl attributes
4) For browser Test use these 2 attributes. Use FireFox -16 for firefox test
5) If you want to run your test in multiple browsers then set browsers=firefox;chrome for example. 
5) If you are running dataset driven frontend tests then , you can use more thread maximum up to 4 for all browsers together

For support

Please send email to 

jana.srimanta@gmail.com or file a ticket. You can also use discussion board and put your topics. You will get your answer very fast