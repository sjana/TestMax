/**
 * Example "Money" for JUnit v3.x.
 */
package scm.wm.samples.money;